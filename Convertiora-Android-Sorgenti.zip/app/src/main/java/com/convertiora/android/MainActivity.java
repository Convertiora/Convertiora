package com.convertiora.android;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.content.ActivityNotFoundException;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Convertiora native Android UI. All primary actions are connected to real conversion code. */
public class MainActivity extends Activity {
    private static final int PICK_FILES = 101;
    private static final int SAVE_FILE = 102;
    private static final int BG = Color.rgb(9, 15, 30);
    private static final int CARD = Color.rgb(21, 30, 51);
    private static final int BORDER = Color.rgb(48, 65, 97);
    private static final int TEXT = Color.rgb(243, 246, 255);
    private static final int MUTED = Color.rgb(159, 173, 196);
    private static final int PRIMARY = Color.rgb(103, 123, 255);
    private static final int ACCENT = Color.rgb(67, 222, 189);

    private final List<ConversionEngine.Source> sources = new ArrayList<>();
    private final List<ConversionEngine.Result> results = new ArrayList<>();
    private final List<ConversionEngine.Target> choices = new ArrayList<>();
    private final ExecutorService workers = Executors.newSingleThreadExecutor();
    private ConversionEngine.Result pendingSave;
    private boolean busy;

    private LinearLayout root, selectedList, resultsList;
    private TextView selectionInfo, hint, progressText, resultTitle;
    private Spinner targetPicker;
    private TextView convertButton;
    private ProgressBar progress;
    private ScrollView scrollView;
    private TextView clearButton;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        render();
        if (savedInstanceState != null) restoreSession(savedInstanceState);
        workers.execute(this::purgeOldCache);
    }

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + .5f); }

    private GradientDrawable shape(int color, int radius, int stroke, int strokeWidth) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (strokeWidth > 0) d.setStroke(dp(strokeWidth), stroke);
        return d;
    }

    private GradientDrawable gradient(int radius) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[] { Color.rgb(31, 46, 91), Color.rgb(16, 27, 54) });
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), Color.rgb(58, 76, 128));
        return d;
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextColor(color);
        v.setTextSize(size);
        if (bold) v.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }

    private LinearLayout vertical() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        return v;
    }

    private LinearLayout horizontal() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.HORIZONTAL);
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }

    private LinearLayout.LayoutParams lp(int width, int height) {
        return new LinearLayout.LayoutParams((width == -1 || width == -2) ? width : dp(width), height == -1 || height == -2 ? height : dp(height));
    }

    private void margin(View v, int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(top);
        root.addView(v, p);
    }

    private TextView pill(String label, int bg, int color) {
        TextView t = text(label, 11, color, true);
        t.setPadding(dp(12), dp(7), dp(12), dp(7));
        t.setBackground(shape(bg, 30, bg, 0));
        return t;
    }

    private void render() {
        scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setBackgroundColor(BG);
        scrollView.setClipToPadding(false);
        root = vertical();
        root.setPadding(dp(20), dp(25), dp(20), dp(32));
        scrollView.addView(root, new ScrollView.LayoutParams(-1, -2));
        setContentView(scrollView);
        if (Build.VERSION.SDK_INT >= 35) {
            scrollView.setOnApplyWindowInsetsListener((v, insets) -> {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                root.setPadding(dp(20), dp(25) + bars.top, dp(20), dp(32) + bars.bottom);
                return insets;
            });
        }
        buildHeader();
        buildHero();
        buildUpload();
        buildCategories();
        buildConvert();
        buildResults();
        buildFooter();
        refreshSources();
        refreshResults();
    }

    private void buildHeader() {
        LinearLayout row = horizontal();
        TextView logo = text("⇄", 29, TEXT, true);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(shape(Color.rgb(46, 63, 132), 16, BORDER, 1));
        row.addView(logo, lp(52, 52));
        LinearLayout brand = vertical();
        brand.setPadding(dp(12), 0, 0, 0);
        brand.addView(text("Convertiora", 23, TEXT, true));
        TextView sub = text("FILE CONVERTER · OFFLINE", 9, MUTED, true);
        sub.setLetterSpacing(.17f);
        LinearLayout.LayoutParams st = lp(-1, -2);
        st.topMargin = dp(2);
        brand.addView(sub, st);
        row.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        TextView help = text("?", 19, MUTED, true);
        help.setGravity(Gravity.CENTER);
        help.setBackground(shape(CARD, 14, BORDER, 1));
        row.addView(help, lp(42, 42));
        help.setContentDescription("Informazioni sulla conversione");
        help.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Convertiora · 1.0")
                .setMessage("Convertiora lavora offline: i file non vengono caricati su server. "
                        + "Il catalogo riconosce " + FormatCatalog.count() + " estensioni, ma la conversione "
                        + "è attiva solo per i percorsi mostrati dopo la selezione del file.\n\n"
                        + "Note: DOCX e ODT sono esportati come testo senza mantenere l'impaginazione; "
                        + "XLSX esporta il primo foglio; GIF utilizza il primo fotogramma; "
                        + "per PDF multipagina le immagini finiscono in uno ZIP; "
                        + "l'estrazione audio richiede una traccia AAC compatibile.\n\n"
                        + "Dimensione massima: 250 MB per file.\n\n"
                        + "Per maggiori informazioni usa il pulsante Privacy in fondo alla schermata.")
                .setPositiveButton("Ho capito", null).show());
        root.addView(row, lp(-1, -2));
    }

    private void buildHero() {
        LinearLayout hero = vertical();
        hero.setPadding(dp(21), dp(22), dp(21), dp(24));
        hero.setBackground(gradient(24));
        LinearLayout labels = horizontal();
        labels.addView(pill("●  100% OFFLINE", Color.rgb(24, 67, 72), ACCENT));
        LinearLayout.LayoutParams privacy = lp(-2, -2);
        privacy.leftMargin = dp(8);
        labels.addView(pill("SENZA ACCOUNT", Color.rgb(42, 54, 91), Color.rgb(183, 192, 255)), privacy);
        hero.addView(labels);
        TextView title = text("Da un formato\nall’altro, facilmente.", 28, TEXT, true);
        title.setLineSpacing(dp(2), 1f);
        LinearLayout.LayoutParams tp = lp(-1, -2);
        tp.topMargin = dp(16);
        hero.addView(title, tp);
        TextView description = text("Converti, salva e condividi direttamente dal tuo Android.", 14, Color.rgb(196, 207, 234), false);
        description.setLineSpacing(dp(2), 1f);
        LinearLayout.LayoutParams descp = lp(-1, -2);
        descp.topMargin = dp(10);
        hero.addView(description, descp);
        margin(hero, 22);
    }

    private void buildUpload() {
        sectionTitle("01", "Seleziona i file");
        LinearLayout upload = vertical();
        upload.setGravity(Gravity.CENTER_HORIZONTAL);
        upload.setPadding(dp(20), dp(24), dp(20), dp(22));
        GradientDrawable outline = shape(Color.rgb(17, 26, 46), 22, Color.rgb(69, 87, 141), 2);
        upload.setBackground(outline);
        TextView icon = text("＋", 33, TEXT, false);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(shape(Color.rgb(50, 67, 135), 19, 0, 0));
        upload.addView(icon, lp(66, 66));
        TextView selectTitle = text("Tocca per scegliere i file", 17, TEXT, true);
        LinearLayout.LayoutParams ttl = lp(-2, -2); ttl.topMargin = dp(14);
        upload.addView(selectTitle, ttl);
        TextView sub = text("Anche più file contemporaneamente", 12, MUTED, false);
        LinearLayout.LayoutParams sl = lp(-2, -2); sl.topMargin = dp(6);
        upload.addView(sub, sl);
        upload.setContentDescription("Scegli file dal dispositivo");
        upload.setOnClickListener(v -> openPicker("*/*"));
        margin(upload, 13);
        selectedList = vertical();
        margin(selectedList, 12);
        selectionInfo = text("Nessun file selezionato", 12, MUTED, false);
        margin(selectionInfo, 8);
    }

    private void buildCategories() {
        sectionTitle("02", "Esplora le categorie");
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(2);
        final String[] symbols = {"▧", "▤", "▦", "♫", "▣", "⌘"};
        final String[] labels = {"Immagini", "Documenti e PDF", "Fogli di calcolo",
                "Audio dai video", "Archivi", "Testo e dati"};
        final String[] subtitles = {"JPG, PNG, WEBP…", "PDF, DOCX, ODT…", "XLSX, CSV, TSV…",
                "MP4, MOV → M4A", "ZIP, TAR", "TXT, HTML, JSON…"};
        for (int i = 0; i < labels.length; i++) {
            LinearLayout card = vertical();
            card.setPadding(dp(13), dp(15), dp(8), dp(14));
            card.setBackground(shape(CARD, 17, BORDER, 1));
            TextView symbol = text(symbols[i], 25, i % 2 == 0 ? ACCENT : Color.rgb(160, 173, 255), true);
            card.addView(symbol);
            TextView title = text(labels[i], 13, TEXT, true);
            LinearLayout.LayoutParams titleLp = lp(-1, -2); titleLp.topMargin = dp(8);
            card.addView(title, titleLp);
            TextView sub = text(subtitles[i], 11, MUTED, false);
            LinearLayout.LayoutParams subLp = lp(-1, -2); subLp.topMargin = dp(3);
            card.addView(sub, subLp);
            GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
            gp.width = 0; gp.height = -2; gp.columnSpec = GridLayout.spec(i % 2, 1f);
            gp.rowSpec = GridLayout.spec(i / 2);
            gp.setMargins(dp(i % 2 == 0 ? 0 : 6), dp(i / 2 == 0 ? 0 : 6),
                    dp(i % 2 == 1 ? 0 : 6), dp(i / 2 == 0 ? 0 : 6));
            grid.addView(card, gp);
            final int index = i;
            card.setOnClickListener(v -> openPicker(index == 0 ? "image/*" : "*/*"));
            card.setContentDescription("Sfoglia " + labels[i]);
        }
        margin(grid, 12);
        TextView note = text("Riconosciute " + FormatCatalog.count() + " estensioni. "
                + "I formati convertibili vengono indicati dopo aver scelto un file.", 12, MUTED, false);
        note.setLineSpacing(dp(3), 1f);
        margin(note, 10);
    }

    private void buildConvert() {
        sectionTitle("03", "Imposta la conversione");
        LinearLayout card = vertical();
        card.setPadding(dp(16), dp(18), dp(16), dp(18));
        card.setBackground(shape(CARD, 21, BORDER, 1));
        card.addView(text("FORMATO DI DESTINAZIONE", 11, Color.rgb(164, 179, 220), true));
        targetPicker = new Spinner(this);
        targetPicker.setBackground(shape(Color.rgb(30, 42, 67), 13, BORDER, 1));
        targetPicker.setPadding(dp(6), 0, dp(9), 0);
        LinearLayout.LayoutParams selectorLp = lp(-1, 55); selectorLp.topMargin = dp(10);
        card.addView(targetPicker, selectorLp);
        hint = text("Scegli prima un file per vedere i formati disponibili.", 12, MUTED, false);
        hint.setLineSpacing(dp(2), 1f);
        LinearLayout.LayoutParams hl = lp(-1, -2); hl.topMargin = dp(10);
        card.addView(hint, hl);
        convertButton = text("⇄   CONVERTI ORA", 16, Color.WHITE, true);
        convertButton.setGravity(Gravity.CENTER);
        convertButton.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[] { Color.rgb(86, 110, 250), Color.rgb(125, 86, 233) }) {{ setCornerRadius(dp(15)); }});
        LinearLayout.LayoutParams btnLp = lp(-1, 58); btnLp.topMargin = dp(20);
        card.addView(convertButton, btnLp);
        convertButton.setContentDescription("Avvia conversione dei file selezionati");
        convertButton.setOnClickListener(v -> startConversions());
        LinearLayout waiting = horizontal();
        waiting.setGravity(Gravity.CENTER);
        progress = new ProgressBar(this);
        progress.setIndeterminateTintList(ColorStateList.valueOf(ACCENT));
        waiting.addView(progress, lp(26, 26));
        progressText = text("Conversione in corso…", 12, MUTED, false);
        LinearLayout.LayoutParams infoLp = lp(-2, -2); infoLp.leftMargin = dp(10);
        waiting.addView(progressText, infoLp);
        LinearLayout.LayoutParams waitingLp = lp(-1, -2); waitingLp.topMargin = dp(13);
        card.addView(waiting, waitingLp);
        waiting.setTag("waiting");
        waiting.setVisibility(View.GONE);
        margin(card, 12);
    }

    private void sectionTitle(String number, String label) {
        LinearLayout row = horizontal();
        TextView numberLabel = text(number, 12, ACCENT, true);
        numberLabel.setLetterSpacing(.05f);
        row.addView(numberLabel);
        TextView title = text(label, 19, TEXT, true);
        LinearLayout.LayoutParams p = lp(-1, -2); p.leftMargin = dp(10);
        row.addView(title, p);
        margin(row, 29);
    }

    private void buildResults() {
        sectionTitle("04", "I tuoi file convertiti");
        resultTitle = text("I risultati compariranno qui dopo la conversione.", 12, MUTED, false);
        margin(resultTitle, 8);
        resultsList = vertical();
        margin(resultsList, 6);
        clearButton = text("ELIMINA I RISULTATI TEMPORANEI", 11, MUTED, true);
        clearButton.setGravity(Gravity.CENTER);
        clearButton.setPadding(dp(13), dp(15), dp(13), dp(15));
        clearButton.setContentDescription("Cancella file convertiti non ancora salvati");
        clearButton.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Eliminare i risultati?")
                .setMessage("I file temporanei saranno eliminati dal dispositivo. I file già salvati non vengono toccati.")
                .setNegativeButton("Annulla", null)
                .setPositiveButton("Elimina", (dialog, which) -> { deletePreviousResults(); refreshResults(); })
                .show());
        margin(clearButton, 8);
    }

    private void buildFooter() {
        TextView footer = text("Convertiora  •  I tuoi file rimangono sul dispositivo\n"
                + "Versione 1.0  •  Nessuna connessione richiesta", 11, MUTED, false);
        footer.setGravity(Gravity.CENTER);
        footer.setLineSpacing(dp(4), 1f);
        margin(footer, 34);
        TextView privacy = text("PRIVACY E TRATTAMENTO DEI FILE", 12, ACCENT, true);
        privacy.setGravity(Gravity.CENTER);
        privacy.setPadding(dp(12), dp(16), dp(12), dp(16));
        privacy.setContentDescription("Apri informativa privacy Convertiora");
        privacy.setOnClickListener(v -> showPrivacy());
        margin(privacy, 7);
    }

    private void openPicker(String type) {
        if (busy) return;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType(type);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(intent, PICK_FILES);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        if (requestCode == PICK_FILES) {
            List<Uri> picked = new ArrayList<>();
            ClipData items = data.getClipData();
            if (items != null) {
                for (int i = 0; i < items.getItemCount() && i < 15; i++)
                    picked.add(items.getItemAt(i).getUri());
            } else if (data.getData() != null) picked.add(data.getData());
            sources.clear(); deletePreviousResults();
            Set<Uri> seen = new HashSet<>();
            for (Uri uri : picked) {
                if (seen.add(uri)) sources.add(readSource(uri));
            }
            refreshSources(); refreshResults();
        } else if (requestCode == SAVE_FILE && pendingSave != null) {
            ConversionEngine.Result toSave = pendingSave;
            pendingSave = null;
            Uri destination = data.getData();
            if (destination == null) return;
            Toast.makeText(this, "Salvataggio in corso…", Toast.LENGTH_SHORT).show();
            workers.execute(() -> {
                try (InputStream in = new FileInputStream(toSave.file);
                     OutputStream out = getContentResolver().openOutputStream(destination)) {
                    if (out == null) throw new IllegalStateException("Destinazione non accessibile");
                    ConversionEngine.copy(in, out, 500L * 1024 * 1024);
                    runOnUiThread(() -> Toast.makeText(this, "File salvato: " + toSave.displayName,
                            Toast.LENGTH_LONG).show());
                } catch (Exception ex) {
                    runOnUiThread(() -> new AlertDialog.Builder(this)
                            .setTitle("Salvataggio non riuscito")
                            .setMessage(ex.getMessage()).setPositiveButton("OK", null).show());
                }
            });
        }
    }

    private ConversionEngine.Source readSource(Uri uri) {
        String name = "file_sconosciuto";
        long size = -1;
        try (Cursor cursor = getContentResolver().query(uri,
                new String[] {OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int nameCol = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                int sizeCol = cursor.getColumnIndex(OpenableColumns.SIZE);
                if (nameCol >= 0 && !cursor.isNull(nameCol)) name = cursor.getString(nameCol);
                if (sizeCol >= 0 && !cursor.isNull(sizeCol)) size = cursor.getLong(sizeCol);
            }
        } catch (Exception ignored) { }
        String ext = ConversionEngine.extensionOf(name);
        if (ext.isEmpty()) {
            String mime = getContentResolver().getType(uri);
            String detected = mime == null ? null : android.webkit.MimeTypeMap.getSingleton().getExtensionFromMimeType(mime);
            if (detected != null) ext = detected.toLowerCase(Locale.ROOT);
        }
        return new ConversionEngine.Source(uri, name, ext, size);
    }

    private void refreshSources() {
        selectedList.removeAllViews();
        if (sources.isEmpty()) {
            selectionInfo.setText("Nessun file selezionato");
        } else {
            selectionInfo.setText(sources.size() == 1 ? "1 file selezionato" : sources.size() + " file selezionati");
            int shown = Math.min(15, sources.size());
            for (int i = 0; i < shown; i++) {
                ConversionEngine.Source src = sources.get(i);
                LinearLayout item = horizontal();
                item.setPadding(dp(12), dp(11), dp(12), dp(11));
                item.setBackground(shape(CARD, 12, BORDER, 1));
                TextView dot = text("●", 10, ACCENT, true);
                item.addView(dot);
                LinearLayout info = vertical();
                info.setPadding(dp(10), 0, 0, 0);
                TextView name = text(src.name, 13, TEXT, true);
                name.setMaxLines(1); name.setEllipsize(android.text.TextUtils.TruncateAt.END);
                info.addView(name);
                String detail = src.extension.isEmpty() ? "Formato sconosciuto" : src.extension.toUpperCase(Locale.ROOT);
                if (src.size >= 0) detail += "  ·  " + humanSize(src.size);
                TextView d = text(detail, 11, MUTED, false);
                LinearLayout.LayoutParams dl = lp(-1, -2); dl.topMargin = dp(2);
                info.addView(d, dl);
                item.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
                LinearLayout.LayoutParams ip = lp(-1, -2); ip.topMargin = dp(5);
                selectedList.addView(item, ip);
            }
        }
        refreshChoices();
    }

    private String humanSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format(Locale.ITALY, "%.1f KB", bytes / 1024f);
        return String.format(Locale.ITALY, "%.1f MB", bytes / (1024f * 1024));
    }

    private void refreshChoices() {
        choices.clear();
        if (!sources.isEmpty()) {
            choices.addAll(ConversionEngine.targets(sources.get(0).extension));
            for (int i = 1; i < sources.size(); i++) {
                List<ConversionEngine.Target> other = ConversionEngine.targets(sources.get(i).extension);
                choices.removeIf(t -> !other.contains(t));
            }
        }
        List<String> labels = new ArrayList<>();
        if (choices.isEmpty()) labels.add("—  Nessun formato disponibile  —");
        else for (ConversionEngine.Target target : choices) labels.add(target.label);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, labels) {
            @Override public View getView(int position, View convertView, ViewGroup parent) {
                TextView v = (TextView) super.getView(position, convertView, parent);
                v.setTextColor(TEXT); v.setTextSize(14);
                v.setPadding(dp(10), dp(8), dp(5), dp(8));
                return v;
            }
            @Override public View getDropDownView(int position, View convertView, ViewGroup parent) {
                TextView v = (TextView) super.getDropDownView(position, convertView, parent);
                v.setTextColor(TEXT); v.setTextSize(14);
                v.setBackgroundColor(Color.rgb(26, 37, 64));
                v.setPadding(dp(16), dp(14), dp(16), dp(14));
                return v;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        targetPicker.setAdapter(adapter);
        if (sources.isEmpty())
            hint.setText("Scegli prima un file per vedere i formati disponibili.");
        else if (choices.isEmpty())
            hint.setText(sources.size() > 1
                    ? "I file scelti non hanno un formato di destinazione in comune. "
                        + "Seleziona file compatibili tra loro."
                    : (FormatCatalog.recognized(sources.get(0).extension)
                        ? "Formato riconosciuto, ma questa conversione non è ancora disponibile offline."
                        : "Questo formato non è supportato da Convertiora."));
        else
            hint.setText("Disponibili " + choices.size() + " conversioni offline per "
                    + (sources.size() == 1 ? "il file selezionato." : "questi " + sources.size() + " file."));
        convertButton.setAlpha(sources.isEmpty() || choices.isEmpty() ? .45f : 1f);
    }

    private void startConversions() {
        if (busy || sources.isEmpty() || choices.isEmpty()) return;
        ConversionEngine.Target target = choices.get(targetPicker.getSelectedItemPosition());
        List<ConversionEngine.Source> batch = new ArrayList<>(sources);
        busy = true;
        deletePreviousResults(); refreshResults();
        convertButton.setAlpha(.5f);
        LinearLayout waiting = (LinearLayout) progress.getParent();
        waiting.setVisibility(View.VISIBLE);
        progressText.setText("Preparazione…");
        workers.execute(() -> {
            List<ConversionEngine.Result> completed = new ArrayList<>();
            List<String> failures = new ArrayList<>();
            for (int i = 0; i < batch.size(); i++) {
                int index = i;
                runOnUiThread(() -> progressText.setText("Conversione " + (index + 1) + "/" + batch.size() + "…"));
                try {
                    completed.add(ConversionEngine.convert(this, batch.get(i), target));
                } catch (Exception ex) {
                    failures.add(batch.get(i).name + ": " +
                            (ex.getMessage() == null ? ex.getClass().getSimpleName() : ex.getMessage()));
                }
            }
            runOnUiThread(() -> {
                results.addAll(completed);
                busy = false;
                waiting.setVisibility(View.GONE);
                refreshChoices(); refreshResults();
                if (!failures.isEmpty()) {
                    new AlertDialog.Builder(this).setTitle("Alcuni file non sono stati convertiti")
                            .setMessage(android.text.TextUtils.join("\n\n", failures))
                            .setPositiveButton("OK", null).show();
                } else if (!completed.isEmpty()) {
                    Toast.makeText(this, "Conversione completata!", Toast.LENGTH_SHORT).show();
                }
                resultTitle.requestFocus();
            });
        });
    }

    private void refreshResults() {
        resultsList.removeAllViews();
        clearButton.setVisibility(results.isEmpty() ? View.GONE : View.VISIBLE);
        if (results.isEmpty()) {
            resultTitle.setText("I risultati compariranno qui dopo la conversione.");
            return;
        }
        resultTitle.setText(results.size() == 1 ? "1 file pronto da salvare o condividere"
                : results.size() + " file pronti da salvare o condividere");
        for (ConversionEngine.Result result : results) {
            LinearLayout card = vertical();
            card.setBackground(shape(CARD, 17, BORDER, 1));
            card.setPadding(dp(15), dp(15), dp(15), dp(15));
            TextView name = text("✓  " + result.displayName, 14, TEXT, true);
            name.setMaxLines(2);
            card.addView(name);
            TextView detail = text(result.detail + "  ·  " + humanSize(result.file.length()), 11, MUTED, false);
            LinearLayout.LayoutParams dl = lp(-1, -2); dl.topMargin = dp(5);
            card.addView(detail, dl);
            LinearLayout actions = horizontal();
            LinearLayout.LayoutParams al = lp(-1, -2); al.topMargin = dp(14);
            TextView save = actionButton("↓  SALVA", PRIMARY);
            TextView share = actionButton("↗  CONDIVIDI", Color.rgb(44, 60, 96));
            LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(0, dp(42), 1);
            actions.addView(save, bl);
            LinearLayout.LayoutParams bl2 = new LinearLayout.LayoutParams(0, dp(42), 1);
            bl2.leftMargin = dp(8);
            actions.addView(share, bl2);
            save.setContentDescription("Salva " + result.displayName);
            share.setContentDescription("Condividi " + result.displayName);
            save.setOnClickListener(v -> saveResult(result));
            share.setOnClickListener(v -> shareResult(result));
            card.addView(actions, al);
            LinearLayout.LayoutParams outer = lp(-1, -2); outer.topMargin = dp(8);
            resultsList.addView(card, outer);
        }
    }

    private TextView actionButton(String label, int bg) {
        TextView v = text(label, 12, TEXT, true);
        v.setGravity(Gravity.CENTER);
        v.setBackground(shape(bg, 11, bg, 0));
        return v;
    }

    private void saveResult(ConversionEngine.Result result) {
        pendingSave = result;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(result.mimeType);
        intent.putExtra(Intent.EXTRA_TITLE, result.displayName);
        startActivityForResult(intent, SAVE_FILE);
    }

    private void shareResult(ConversionEngine.Result result) {
        Uri uri = ShareProvider.shareUri(this, result);
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType(result.mimeType);
        intent.putExtra(Intent.EXTRA_STREAM, uri);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.setClipData(ClipData.newUri(getContentResolver(), result.displayName, uri));
        startActivity(Intent.createChooser(intent, "Condividi " + result.displayName));
    }

    private void showPrivacy() {
        String text = "INFORMATIVA PRIVACY · CONVERTIORA\n\n"
                + "Convertiora funziona completamente offline. Non richiede registrazione, "
                + "non mostra pubblicità, non usa analytics e non invia i tuoi documenti su server.\n\n"
                + "I file scelti attraverso il selettore di Android vengono letti "
                + "esclusivamente per effettuare la conversione richiesta. Una copia temporanea "
                + "può essere conservata nella cache privata dell'app finché non la elimini, "
                + "selezioni nuovi file o Android libera la cache. I file salvati restano nella "
                + "destinazione che hai scelto.\n\n"
                + "L'app non richiede il permesso Internet né l'accesso generale alla memoria. "
                + "La condivisione dei file avviene soltanto quando la richiedi e attraverso "
                + "le applicazioni che scegli.\n\n"
                + "Per contattare lo sviluppatore, utilizza i recapiti mostrati nella scheda "
                + "ufficiale dell'app su Google Play. Puoi trovare la versione integrale "
                + "dell'informativa nella scheda del negozio.";
        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle("Privacy Convertiora")
                .setMessage(text)
                .setPositiveButton("Chiudi", null);
        String url = getString(R.string.privacy_policy_url);
        if (url.startsWith("https://")) {
            builder.setNeutralButton("Informativa online", (dialog, which) -> {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(this, "Nessun browser disponibile", Toast.LENGTH_LONG).show();
                }
            });
        }
        builder.show();
    }

    private void deletePreviousResults() {
        for (ConversionEngine.Result result : results) {
            if (result.file.getParentFile() != null &&
                    result.file.getParentFile().equals(new File(getCacheDir(), "converted"))) {
                result.file.delete();
            }
        }
        results.clear();
    }

    private void purgeOldCache() {
        File dir = new File(getCacheDir(), "converted");
        File[] files = dir.listFiles();
        if (files == null) return;
        long cutoff = System.currentTimeMillis() - 24L * 60 * 60 * 1000;
        for (File file : files) if (file.isFile() && file.lastModified() < cutoff) file.delete();
    }

    @Override protected void onSaveInstanceState(Bundle state) {
        super.onSaveInstanceState(state);
        ArrayList<String> uris = new ArrayList<>();
        ArrayList<String> names = new ArrayList<>();
        ArrayList<String> exts = new ArrayList<>();
        long[] sizes = new long[sources.size()];
        for (int i = 0; i < sources.size(); i++) {
            ConversionEngine.Source src = sources.get(i);
            uris.add(src.uri.toString()); names.add(src.name); exts.add(src.extension);
            sizes[i] = src.size;
        }
        state.putStringArrayList("source_uri", uris);
        state.putStringArrayList("source_name", names);
        state.putStringArrayList("source_ext", exts);
        state.putLongArray("source_size", sizes);
        ArrayList<String> files = new ArrayList<>();
        ArrayList<String> outputNames = new ArrayList<>();
        ArrayList<String> types = new ArrayList<>();
        ArrayList<String> details = new ArrayList<>();
        for (ConversionEngine.Result result : results) {
            files.add(result.file.getName()); outputNames.add(result.displayName);
            types.add(result.mimeType); details.add(result.detail);
        }
        state.putStringArrayList("result_file", files);
        state.putStringArrayList("result_name", outputNames);
        state.putStringArrayList("result_type", types);
        state.putStringArrayList("result_detail", details);
    }

    private void restoreSession(Bundle state) {
        ArrayList<String> uris = state.getStringArrayList("source_uri");
        ArrayList<String> names = state.getStringArrayList("source_name");
        ArrayList<String> exts = state.getStringArrayList("source_ext");
        long[] sizes = state.getLongArray("source_size");
        if (uris != null && names != null && exts != null && sizes != null) {
            for (int i = 0; i < uris.size() && i < names.size() && i < exts.size()
                    && i < sizes.length; i++) {
                sources.add(new ConversionEngine.Source(Uri.parse(uris.get(i)),
                        names.get(i), exts.get(i), sizes[i]));
            }
        }
        ArrayList<String> files = state.getStringArrayList("result_file");
        ArrayList<String> outputNames = state.getStringArrayList("result_name");
        ArrayList<String> types = state.getStringArrayList("result_type");
        ArrayList<String> details = state.getStringArrayList("result_detail");
        if (files != null && outputNames != null && types != null && details != null) {
            File dir = new File(getCacheDir(), "converted");
            for (int i = 0; i < files.size() && i < outputNames.size()
                    && i < types.size() && i < details.size(); i++) {
                String fileName = files.get(i);
                if (!fileName.matches("[a-zA-Z0-9_-]+\\.[a-zA-Z0-9]+")) continue;
                File file = new File(dir, fileName);
                if (file.isFile()) results.add(new ConversionEngine.Result(file,
                        outputNames.get(i), types.get(i), details.get(i)));
            }
        }
        refreshSources(); refreshResults();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        workers.shutdown();
    }
}
