# Opzioni R8 per il codice Android nativo.
# Nessuna libreria esterna o regola personalizzata necessaria.
