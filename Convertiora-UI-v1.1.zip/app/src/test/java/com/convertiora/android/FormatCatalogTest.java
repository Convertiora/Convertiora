package com.convertiora.android;

import org.junit.Test;
import java.util.List;
import static org.junit.Assert.*;

public class FormatCatalogTest {
    @Test public void catalogRecognitionDoesNotImplyConversion() {
        assertTrue(FormatCatalog.recognized("rar"));
        assertTrue(FormatCatalog.recognized("pdf"));
        assertTrue(FormatCatalog.count() >= 100);
        assertTrue(ConversionEngine.targets("rar").isEmpty());
    }

    @Test public void imageConversionTargetsAreRealAndDistinct() {
        List<ConversionEngine.Target> list = ConversionEngine.targets("png");
        assertTrue(list.contains(new ConversionEngine.Target("jpg", "JPG")));
        assertTrue(list.contains(new ConversionEngine.Target("pdf", "PDF")));
        assertFalse(list.contains(new ConversionEngine.Target("png", "PNG")));
    }

    @Test public void predictableExtractionAndArchivePaths() {
        assertTrue(ConversionEngine.targets("zip").contains(new ConversionEngine.Target("tar", "TAR")));
        assertTrue(ConversionEngine.targets("mp4").contains(new ConversionEngine.Target("m4a", "M4A")));
        assertTrue(ConversionEngine.targets("doc").isEmpty());
        assertEquals("png", ConversionEngine.extensionOf(".hidden.png"));
        assertEquals("", ConversionEngine.extensionOf("NO_EXTENSION"));
    }
}
