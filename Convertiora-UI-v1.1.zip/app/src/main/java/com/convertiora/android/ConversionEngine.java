package com.convertiora.android;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.graphics.pdf.PdfRenderer;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.text.Html;
import android.util.Xml;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.xmlpull.v1.XmlPullParser;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/** Real, fully offline conversion pathways. Unsupported inputs are never shown as convertible. */
public final class ConversionEngine {
    private ConversionEngine() { }

    private static final Set<String> IMAGES = new HashSet<>(Arrays.asList(
            "jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif", "avif"));
    private static final Set<String> TEXTS = new HashSet<>(Arrays.asList(
            "txt", "md", "log", "html", "htm", "json", "xml", "csv", "tsv"));
    private static final Set<String> VIDEO = new HashSet<>(Arrays.asList("mp4", "mov", "m4v", "3gp"));

    public static final class Target {
        public final String extension;
        public final String label;
        public Target(String extension, String label) {
            this.extension = extension;
            this.label = label;
        }
        @Override public String toString() { return label; }
        @Override public boolean equals(Object o) {
            return o instanceof Target && extension.equals(((Target) o).extension);
        }
        @Override public int hashCode() { return extension.hashCode(); }
    }

    public static final class Source {
        public final Uri uri;
        public final String name;
        public final String extension;
        public final long size;
        public Source(Uri uri, String name, String extension, long size) {
            this.uri = uri;
            this.name = name;
            this.extension = extension;
            this.size = size;
        }
    }

    public static final class Result {
        public final File file;
        public final String displayName;
        public final String mimeType;
        public final String detail;
        public Result(File file, String displayName, String mimeType, String detail) {
            this.file = file;
            this.displayName = displayName;
            this.mimeType = mimeType;
            this.detail = detail;
        }
    }

    public static String extensionOf(String name) {
        int dot = name.lastIndexOf('.');
        return dot < 0 || dot == name.length() - 1 ? "" : name.substring(dot + 1).toLowerCase(Locale.ROOT);
    }

    public static boolean recognized(String ext) {
        return FormatCatalog.recognized(ext);
    }

    public static List<Target> targets(String input) {
        List<Target> result = new ArrayList<>();
        if (IMAGES.contains(input)) {
            addDifferent(result, input, "jpg", "JPG · immagine");
            addDifferent(result, input, "png", "PNG · senza perdita");
            addDifferent(result, input, "webp", "WEBP · immagine");
            addDifferent(result, input, "pdf", "PDF · pagina A4");
        } else if ("pdf".equals(input)) {
            result.add(new Target("png", "PNG · tutte le pagine"));
            result.add(new Target("jpg", "JPG · tutte le pagine"));
        } else if (TEXTS.contains(input) || "docx".equals(input) || "odt".equals(input) || "xlsx".equals(input)) {
            if (!"txt".equals(input)) result.add(new Target("txt", "TXT · testo semplice"));
            if (!"pdf".equals(input)) result.add(new Target("pdf", "PDF · documento"));
            if (!"html".equals(input) && !"htm".equals(input) && !"xlsx".equals(input))
                result.add(new Target("html", "HTML · pagina web"));
            if ("csv".equals(input) || "xlsx".equals(input))
                result.add(new Target("tsv", "TSV · dati tabulari"));
            if ("tsv".equals(input) || "xlsx".equals(input))
                result.add(new Target("csv", "CSV · dati tabulari"));
        } else if ("zip".equals(input)) {
            result.add(new Target("tar", "TAR · archivio non compresso"));
            result.add(new Target("txt", "TXT · elenco dei file"));
        } else if ("tar".equals(input)) {
            result.add(new Target("zip", "ZIP · archivio compresso"));
        } else if (VIDEO.contains(input)) {
            result.add(new Target("m4a", "M4A · estrai audio AAC"));
        }
        // Do not present outputs unsupported by the engine.
        return result;
    }

    private static void addDifferent(List<Target> result, String source, String ext, String label) {
        if (!ext.equals(source) && !("jpeg".equals(source) && "jpg".equals(ext)))
            result.add(new Target(ext, label));
    }

    public static String mime(String ext) {
        switch (ext) {
            case "pdf": return "application/pdf";
            case "jpg": return "image/jpeg";
            case "png": return "image/png";
            case "webp": return "image/webp";
            case "zip": return "application/zip";
            case "tar": return "application/x-tar";
            case "txt": return "text/plain";
            case "csv": return "text/csv";
            case "tsv": return "text/tab-separated-values";
            case "html": return "text/html";
            case "m4a": return "audio/mp4";
            default: return "application/octet-stream";
        }
    }

    public static Result convert(Context context, Source source, Target target) throws Exception {
        if (!targets(source.extension).contains(target))
            throw new IOException("Questa coppia di formati non è ancora disponibile.");
        if (source.size > 250L * 1024 * 1024)
            throw new IOException("Il limite è 250 MB per file.");
        File dir = new File(context.getCacheDir(), "converted");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Impossibile preparare la cartella.");
        String id = UUID.randomUUID().toString().substring(0, 12);
        String base = cleanBase(source.name);
        String outExt = target.extension;
        File output = new File(dir, id + "." + outExt);
        File temp = new File(context.getCacheDir(), "source_" + id + ".tmp");
        String detail = "Creato offline sul telefono";
        try {
            copyUri(context, source.uri, temp, 250L * 1024 * 1024);
            if (IMAGES.contains(source.extension)) {
                Bitmap bitmap = decodeBitmap(temp);
                if (bitmap == null) throw new IOException("Il dispositivo non riesce a leggere questa immagine.");
                try {
                    if ("pdf".equals(outExt)) imageToPdf(bitmap, output);
                    else writeBitmap(bitmap, output, outExt);
                    if ("gif".equals(source.extension)) detail = "Convertito il primo fotogramma della GIF";
                } finally {
                    bitmap.recycle();
                }
            } else if ("pdf".equals(source.extension)) {
                int pages = pdfToImages(temp, output, outExt);
                if (pages > 1) {
                    File renamed = new File(dir, id + ".zip");
                    if (!output.renameTo(renamed)) throw new IOException("Impossibile creare ZIP delle pagine.");
                    output = renamed;
                    outExt = "zip";
                    base += "_pagine";
                    detail = pages + " pagine esportate in un archivio ZIP";
                } else {
                    detail = "1 pagina esportata";
                }
            } else if ("zip".equals(source.extension)) {
                if ("tar".equals(outExt)) zipToTar(temp, output);
                else zipListing(temp, output);
            } else if ("tar".equals(source.extension)) {
                tarToZip(temp, output);
            } else if (VIDEO.contains(source.extension)) {
                extractAacAudio(context, source.uri, output);
                detail = "Traccia AAC originale estratta senza ricodifica";
            } else {
                String inputText;
                if ("docx".equals(source.extension)) {
                    inputText = officeText(temp, "word/document.xml", false);
                    detail = "Testo estratto; impaginazione originale non mantenuta";
                } else if ("odt".equals(source.extension)) {
                    inputText = officeText(temp, "content.xml", true);
                    detail = "Testo estratto; impaginazione originale non mantenuta";
                } else if ("xlsx".equals(source.extension)) {
                    inputText = readXlsxFirstSheet(temp);
                    detail = "Esportato il primo foglio senza formule o formattazione";
                } else {
                    inputText = readText(temp);
                    if ("html".equals(source.extension) || "htm".equals(source.extension))
                        inputText = Html.fromHtml(inputText, Html.FROM_HTML_MODE_LEGACY).toString();
                }
                if ("csv".equals(source.extension) && "tsv".equals(outExt)) {
                    writeText(output, delimitedConvert(inputText, ',', '\t'));
                } else if ("tsv".equals(source.extension) && "csv".equals(outExt)) {
                    writeText(output, delimitedConvert(inputText, '\t', ','));
                } else if ("xlsx".equals(source.extension) && "csv".equals(outExt)) {
                    writeText(output, delimitedConvert(inputText, '\t', ','));
                } else if ("xlsx".equals(source.extension) && "tsv".equals(outExt)) {
                    writeText(output, inputText);
                } else if ("pdf".equals(outExt)) {
                    textToPdf(inputText, output, source.name);
                } else if ("html".equals(outExt)) {
                    writeText(output, "<!doctype html><html lang=\"it\"><head><meta charset=\"utf-8\">"
                            + "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
                            + "<title>Documento Convertiora</title></head><body><pre style=\"white-space:pre-wrap;"
                            + "font:16px/1.6 sans-serif\">" + htmlEscape(inputText) + "</pre></body></html>");
                    detail = "Testo inserito in una pagina HTML";
                } else {
                    writeText(output, inputText);
                }
            }
            // For multipage PDFs pdfToImages switches to ZIP using the same on-disk file.
            if (!output.isFile() || output.length() == 0) throw new IOException("File di uscita vuoto.");
            return new Result(output, base + "_convertito." + outExt, mime(outExt), detail);
        } catch (Exception ex) {
            output.delete();
            throw ex;
        } finally {
            temp.delete();
        }
    }

    private static String cleanBase(String name) {
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name;
        base = Normalizer.normalize(base, Normalizer.Form.NFC).replaceAll("[^\\p{L}\\p{N}_-]", "_");
        if (base.isEmpty()) base = "file";
        return base.length() > 60 ? base.substring(0, 60) : base;
    }

    public static void copy(InputStream in, OutputStream out, long maxBytes) throws IOException {
        byte[] buffer = new byte[32 * 1024];
        long total = 0;
        int n;
        while ((n = in.read(buffer)) != -1) {
            total += n;
            if (total > maxBytes) throw new IOException("File troppo grande per questa versione.");
            out.write(buffer, 0, n);
        }
    }

    private static void copyUri(Context ctx, Uri uri, File file, long limit) throws IOException {
        try (InputStream in = ctx.getContentResolver().openInputStream(uri);
             OutputStream out = new BufferedOutputStream(new FileOutputStream(file))) {
            if (in == null) throw new IOException("Impossibile aprire il file selezionato.");
            copy(in, out, limit);
        }
    }

    private static Bitmap decodeBitmap(File source) throws IOException {
        BitmapFactory.Options probe = new BitmapFactory.Options();
        probe.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(source.getAbsolutePath(), probe);
        int w = probe.outWidth, h = probe.outHeight;
        if (w < 1 || h < 1) return null;
        BitmapFactory.Options opt = new BitmapFactory.Options();
        opt.inSampleSize = 1;
        while ((long) (w / opt.inSampleSize) * (h / opt.inSampleSize) > 13_000_000L
                || w / opt.inSampleSize > 4200 || h / opt.inSampleSize > 4200) {
            opt.inSampleSize *= 2;
        }
        try {
            Bitmap bitmap = BitmapFactory.decodeFile(source.getAbsolutePath(), opt);
            if (bitmap == null) return null;
            try {
                // Le foto scattate dal telefono spesso conservano la rotazione nei metadati EXIF.
                ExifInterface exif = new ExifInterface(source.getAbsolutePath());
                int orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION,
                        ExifInterface.ORIENTATION_NORMAL);
                Matrix matrix = new Matrix();
                switch (orientation) {
                    case ExifInterface.ORIENTATION_ROTATE_90: matrix.postRotate(90); break;
                    case ExifInterface.ORIENTATION_ROTATE_180: matrix.postRotate(180); break;
                    case ExifInterface.ORIENTATION_ROTATE_270: matrix.postRotate(270); break;
                    case ExifInterface.ORIENTATION_FLIP_HORIZONTAL: matrix.postScale(-1, 1); break;
                    case ExifInterface.ORIENTATION_FLIP_VERTICAL: matrix.postScale(1, -1); break;
                    case ExifInterface.ORIENTATION_TRANSPOSE:
                        matrix.postScale(-1, 1); matrix.postRotate(270); break;
                    case ExifInterface.ORIENTATION_TRANSVERSE:
                        matrix.postScale(-1, 1); matrix.postRotate(90); break;
                    default: break;
                }
                if (!matrix.isIdentity()) {
                    Bitmap corrected = Bitmap.createBitmap(bitmap, 0, 0,
                            bitmap.getWidth(), bitmap.getHeight(), matrix, true);
                    if (corrected != bitmap) bitmap.recycle();
                    bitmap = corrected;
                }
            } catch (IOException ignored) {
                // Alcuni formati non supportano metadati EXIF.
            }
            return bitmap;
        } catch (OutOfMemoryError oom) {
            throw new IOException("Immagine troppo grande per la memoria disponibile.");
        }
    }

    private static void writeBitmap(Bitmap bmp, File dest, String ext) throws IOException {
        Bitmap.CompressFormat format = "png".equals(ext) ? Bitmap.CompressFormat.PNG
                : "webp".equals(ext) ? (Build.VERSION.SDK_INT >= 30
                ? Bitmap.CompressFormat.WEBP_LOSSY : Bitmap.CompressFormat.WEBP)
                : Bitmap.CompressFormat.JPEG;
        if (format == Bitmap.CompressFormat.JPEG && bmp.hasAlpha()) {
            Bitmap solid = Bitmap.createBitmap(bmp.getWidth(), bmp.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(solid);
            canvas.drawColor(Color.WHITE);
            canvas.drawBitmap(bmp, 0, 0, null);
            try (OutputStream out = new BufferedOutputStream(new FileOutputStream(dest))) {
                if (!solid.compress(format, 90, out)) throw new IOException("Impossibile codificare JPG.");
            } finally { solid.recycle(); }
        } else {
            try (OutputStream out = new BufferedOutputStream(new FileOutputStream(dest))) {
                if (!bmp.compress(format, 90, out)) throw new IOException("Codifica immagine non riuscita.");
            }
        }
    }

    private static void imageToPdf(Bitmap bmp, File dest) throws IOException {
        PdfDocument pdf = new PdfDocument();
        try {
            PdfDocument.Page page = pdf.startPage(new PdfDocument.PageInfo.Builder(595, 842, 1).create());
            Canvas canvas = page.getCanvas();
            canvas.drawColor(Color.WHITE);
            float scale = Math.min(523f / bmp.getWidth(), 770f / bmp.getHeight());
            float width = bmp.getWidth() * scale, height = bmp.getHeight() * scale;
            android.graphics.RectF rect = new android.graphics.RectF((595 - width) / 2, (842 - height) / 2,
                    (595 + width) / 2, (842 + height) / 2);
            Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            canvas.drawBitmap(bmp, null, rect, paint);
            pdf.finishPage(page);
            try (OutputStream out = new FileOutputStream(dest)) { pdf.writeTo(out); }
        } finally { pdf.close(); }
    }

    private static int pdfToImages(File input, File target, String requestedExt) throws Exception {
        try (ParcelFileDescriptor fd = ParcelFileDescriptor.open(input, ParcelFileDescriptor.MODE_READ_ONLY);
             PdfRenderer pdf = new PdfRenderer(fd)) {
            int pages = pdf.getPageCount();
            if (pages == 0) throw new IOException("PDF senza pagine.");
            if (pages > 80) throw new IOException("Massimo 80 pagine per conversione PDF.");
            if (pages == 1) {
                try (PdfRenderer.Page page = pdf.openPage(0)) {
                    Bitmap image = renderPage(page);
                    try { writeBitmap(image, target, requestedExt); }
                    finally { image.recycle(); }
                }
            } else {
                try (ZipOutputStream zip = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(target)))) {
                    for (int i = 0; i < pages; i++) {
                        try (PdfRenderer.Page page = pdf.openPage(i)) {
                            Bitmap image = renderPage(page);
                            try {
                                ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                                image.compress("png".equals(requestedExt)
                                        ? Bitmap.CompressFormat.PNG : Bitmap.CompressFormat.JPEG, 89, buffer);
                                zip.putNextEntry(new ZipEntry(String.format(Locale.ROOT,
                                        "pagina_%03d.%s", i + 1, requestedExt)));
                                buffer.writeTo(zip);
                                zip.closeEntry();
                            } finally { image.recycle(); }
                        }
                    }
                }
            }
            return pages;
        }
    }

    private static Bitmap renderPage(PdfRenderer.Page page) {
        float factor = Math.min(2.4f, Math.min(2400f / page.getWidth(), 2400f / page.getHeight()));
        int w = Math.max(1, Math.round(page.getWidth() * factor));
        int h = Math.max(1, Math.round(page.getHeight() * factor));
        Bitmap bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        bitmap.eraseColor(Color.WHITE);
        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
        return bitmap;
    }

    private static String readText(File input) throws IOException {
        if (input.length() > 15 * 1024 * 1024L)
            throw new IOException("Massimo 15 MB per i documenti di testo.");
        try (InputStream in = new FileInputStream(input)) {
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            copy(in, buffer, 15L * 1024 * 1024);
            byte[] data = buffer.toByteArray();
            String raw = new String(data, StandardCharsets.UTF_8);
            if (raw.length() > 0 && raw.charAt(0) == '\ufeff') raw = raw.substring(1);
            return raw;
        }
    }

    private static void writeText(File output, String value) throws IOException {
        try (FileOutputStream out = new FileOutputStream(output)) {
            out.write(value.getBytes(StandardCharsets.UTF_8));
        }
    }

    private static String htmlEscape(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;");
    }

    /** Text PDFs are freshly typeset; they do not pretend to preserve original Office layout. */
    private static void textToPdf(String body, File output, String title) throws IOException {
        PdfDocument doc = new PdfDocument();
        Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        text.setColor(Color.rgb(28, 38, 58));
        text.setTextSize(11.2f);
        Paint header = new Paint(Paint.ANTI_ALIAS_FLAG);
        header.setColor(Color.rgb(65, 82, 150));
        header.setTextSize(9f);
        float left = 45f, right = 550f, baseline = 80f;
        int pageNumber = 0;
        PdfDocument.Page page = null;
        Canvas canvas = null;
        try {
            String[] lines = body.replace("\r\n", "\n").replace('\r', '\n').split("\n", -1);
            for (String line : lines) {
                if (line.isEmpty()) {
                    if (page == null || baseline > 791) {
                        if (page != null) doc.finishPage(page);
                        page = doc.startPage(new PdfDocument.PageInfo.Builder(595, 842, ++pageNumber).create());
                        canvas = page.getCanvas(); canvas.drawColor(Color.WHITE);
                        canvas.drawText("Convertiora  •  " + shortTitle(title), left, 42, header);
                        baseline = 80;
                    }
                    baseline += 17;
                    continue;
                }
                String remaining = line.replace('\t', ' ');
                while (!remaining.isEmpty()) {
                    if (page == null || baseline > 791) {
                        if (page != null) doc.finishPage(page);
                        if (pageNumber >= 200) throw new IOException("Documento troppo lungo (massimo 200 pagine).");
                        page = doc.startPage(new PdfDocument.PageInfo.Builder(595, 842, ++pageNumber).create());
                        canvas = page.getCanvas(); canvas.drawColor(Color.WHITE);
                        canvas.drawText("Convertiora  •  " + shortTitle(title), left, 42, header);
                        baseline = 80;
                    }
                    int count = text.breakText(remaining, true, right - left, null);
                    if (count <= 0) count = 1;
                    if (count < remaining.length()) {
                        int lastSpace = remaining.lastIndexOf(' ', count);
                        if (lastSpace > count / 2) count = lastSpace + 1;
                    }
                    String portion = remaining.substring(0, count);
                    canvas.drawText(portion, left, baseline, text);
                    remaining = remaining.substring(count);
                    baseline += 17;
                }
            }
            if (page == null) {
                page = doc.startPage(new PdfDocument.PageInfo.Builder(595, 842, 1).create());
                page.getCanvas().drawColor(Color.WHITE);
            }
            doc.finishPage(page);
            try (FileOutputStream out = new FileOutputStream(output)) { doc.writeTo(out); }
        } finally { doc.close(); }
    }

    private static String shortTitle(String name) {
        return name.length() > 58 ? name.substring(0, 58) : name;
    }

    /** Pull-parser avoids bringing a third-party Office suite into the Android application. */
    private static String officeText(File file, String entryName, boolean odt) throws Exception {
        try (ZipFile zip = new ZipFile(file)) {
            ZipEntry entry = zip.getEntry(entryName);
            if (entry == null) throw new IOException("Documento Office danneggiato o non valido.");
            if (entry.getSize() > 20 * 1024 * 1024L) throw new IOException("Documento troppo grande.");
            try (InputStream input = zip.getInputStream(entry)) {
                XmlPullParser parser = Xml.newPullParser();
                parser.setInput(input, "UTF-8");
                StringBuilder out = new StringBuilder();
                boolean text = false;
                int event;
                while ((event = parser.next()) != XmlPullParser.END_DOCUMENT) {
                    String name = parser.getName();
                    if (event == XmlPullParser.START_TAG) {
                        if ("t".equals(name) && !odt) text = true;
                        if (odt && ("p".equals(name) || "h".equals(name))) text = true;
                        if (!odt && "tab".equals(name)) out.append('\t');
                        if (!odt && "br".equals(name)) out.append('\n');
                    } else if (event == XmlPullParser.TEXT && text) {
                        out.append(parser.getText());
                        if (out.length() > 12_000_000) throw new IOException("Testo Office troppo grande.");
                    } else if (event == XmlPullParser.END_TAG) {
                        if (!odt && "t".equals(name)) text = false;
                        if ((!odt && "p".equals(name)) || (odt && ("p".equals(name) || "h".equals(name)))) {
                            out.append('\n');
                            if (odt) text = false;
                        }
                    }
                }
                return out.toString();
            }
        }
    }

    private static String readXlsxFirstSheet(File file) throws Exception {
        try (ZipFile zip = new ZipFile(file)) {
            List<String> shared = new ArrayList<>();
            ZipEntry strings = zip.getEntry("xl/sharedStrings.xml");
            if (strings != null) {
                try (InputStream in = zip.getInputStream(strings)) {
                    XmlPullParser p = Xml.newPullParser(); p.setInput(in, "UTF-8");
                    StringBuilder current = null; int event;
                    while ((event = p.next()) != XmlPullParser.END_DOCUMENT) {
                        String tag = p.getName();
                        if (event == XmlPullParser.START_TAG && "si".equals(tag)) current = new StringBuilder();
                        else if (event == XmlPullParser.START_TAG && "t".equals(tag) && current != null)
                            current.append(p.nextText());
                        else if (event == XmlPullParser.END_TAG && "si".equals(tag) && current != null) {
                            shared.add(current.toString()); current = null;
                            if (shared.size() > 200_000) throw new IOException("Troppi dati nel foglio.");
                        }
                    }
                }
            }
            ZipEntry sheet = zip.getEntry("xl/worksheets/sheet1.xml");
            if (sheet == null) throw new IOException("Primo foglio XLSX non disponibile.");
            try (InputStream in = zip.getInputStream(sheet)) {
                XmlPullParser p = Xml.newPullParser(); p.setInput(in, "UTF-8");
                StringBuilder result = new StringBuilder();
                List<String> row = null;
                String cellType = null;
                int cellIndex = -1;
                String value = "";
                int rows = 0;
                int event;
                while ((event = p.next()) != XmlPullParser.END_DOCUMENT) {
                    String tag = p.getName();
                    if (event == XmlPullParser.START_TAG && "row".equals(tag)) row = new ArrayList<>();
                    else if (event == XmlPullParser.START_TAG && "c".equals(tag)) {
                        String ref = p.getAttributeValue(null, "r");
                        cellIndex = columnIndex(ref);
                        cellType = p.getAttributeValue(null, "t");
                        value = "";
                    } else if (event == XmlPullParser.START_TAG && ("v".equals(tag) || "t".equals(tag))) {
                        value = p.nextText();
                    } else if (event == XmlPullParser.END_TAG && "c".equals(tag) && row != null) {
                        if ("s".equals(cellType)) {
                            try { value = shared.get(Integer.parseInt(value)); }
                            catch (Exception e) { value = ""; }
                        }
                        int index = cellIndex < 0 ? row.size() : cellIndex;
                        if (index > 500) throw new IOException("Massimo 500 colonne XLSX.");
                        while (row.size() <= index) row.add("");
                        row.set(index, value);
                    } else if (event == XmlPullParser.END_TAG && "row".equals(tag) && row != null) {
                        if (rows++ >= 10000) throw new IOException("Massimo 10.000 righe XLSX.");
                        for (int j = 0; j < row.size(); j++) {
                            if (j > 0) result.append('\t');
                            result.append(escapeDelimitedCell(row.get(j), '\t'));
                        }
                        result.append('\n'); row = null;
                        if (result.length() > 15_000_000) throw new IOException("Troppi dati XLSX.");
                    }
                }
                return result.toString();
            }
        }
    }

    private static int columnIndex(String ref) {
        if (ref == null) return -1;
        int index = 0, n = 0;
        while (n < ref.length() && Character.isLetter(ref.charAt(n))) {
            index = index * 26 + (Character.toUpperCase(ref.charAt(n)) - 'A' + 1); n++;
        }
        return n == 0 ? -1 : index - 1;
    }

    /** Correctly handles quotes, commas/tabs and embedded line breaks. */
    private static String delimitedConvert(String text, char from, char to) {
        StringBuilder out = new StringBuilder();
        StringBuilder cell = new StringBuilder();
        boolean quoted = false;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '"') {
                if (quoted && i + 1 < text.length() && text.charAt(i + 1) == '"') {
                    cell.append('"'); i++;
                } else quoted = !quoted;
            } else if (!quoted && (c == from || c == '\n' || c == '\r')) {
                out.append(escapeDelimitedCell(cell.toString(), to)); cell.setLength(0);
                if (c == from) out.append(to);
                else if (c == '\n') out.append('\n');
                else if (i + 1 >= text.length() || text.charAt(i + 1) != '\n') out.append('\n');
            } else {
                cell.append(c);
            }
        }
        if (cell.length() > 0) out.append(escapeDelimitedCell(cell.toString(), to));
        return out.toString();
    }

    private static String escapeDelimitedCell(String cell, char delimiter) {
        if (cell.indexOf(delimiter) >= 0 || cell.indexOf('"') >= 0 || cell.indexOf('\n') >= 0) {
            return "\"" + cell.replace("\"", "\"\"") + "\"";
        }
        return cell;
    }

    private static void zipListing(File zipFile, File target) throws IOException {
        StringBuilder list = new StringBuilder("CONTENUTO ARCHIVIO\n\n");
        try (ZipFile zip = new ZipFile(zipFile)) {
            java.util.Enumeration<? extends ZipEntry> entries = zip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry item = entries.nextElement();
                list.append(item.getName()).append("  [").append(item.getSize()).append(" byte]\n");
                if (list.length() > 10_000_000) throw new IOException("Archivio troppo grande.");
            }
        }
        writeText(target, list.toString());
    }

    private static void zipToTar(File input, File output) throws IOException {
        long bytes = 0; int count = 0;
        try (ZipFile zip = new ZipFile(input); OutputStream out = new BufferedOutputStream(new FileOutputStream(output))) {
            java.util.Enumeration<? extends ZipEntry> entries = zip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                String name = safeEntryName(entry.getName());
                if (name.isEmpty()) continue;
                if (++count > 1500) throw new IOException("Massimo 1.500 file per archivio.");
                long length = entry.isDirectory() ? 0 : entry.getSize();
                if (length < 0 || length > 150L * 1024 * 1024 || bytes + length > 200L * 1024 * 1024)
                    throw new IOException("Archivio decompresso troppo grande.");
                bytes += length;
                if (name.getBytes(StandardCharsets.UTF_8).length > 100)
                    throw new IOException("Nome interno troppo lungo per TAR: " + name);
                writeTarHeader(out, name, length, entry.isDirectory());
                if (!entry.isDirectory()) {
                    try (InputStream in = zip.getInputStream(entry)) { copyExact(in, out, length); }
                    int pad = (int) ((512 - length % 512) % 512);
                    out.write(new byte[pad]);
                }
            }
            out.write(new byte[1024]);
        }
    }

    private static String safeEntryName(String name) {
        String normalized = name.replace('\\', '/');
        if (normalized.startsWith("/") || normalized.startsWith("../") || normalized.contains("/../")
                || normalized.equals("..") || normalized.indexOf('\u0000') >= 0) return "";
        return normalized;
    }

    private static void writeTarHeader(OutputStream out, String name, long size, boolean dir) throws IOException {
        byte[] h = new byte[512];
        byte[] n = name.getBytes(StandardCharsets.UTF_8);
        System.arraycopy(n, 0, h, 0, Math.min(n.length, 100));
        tarOctal(h, 100, 8, dir ? 0755 : 0644);
        tarOctal(h, 108, 8, 0); tarOctal(h, 116, 8, 0);
        tarOctal(h, 124, 12, size); tarOctal(h, 136, 12, System.currentTimeMillis() / 1000);
        Arrays.fill(h, 148, 156, (byte) ' ');
        h[156] = (byte) (dir ? '5' : '0');
        byte[] magic = "ustar".getBytes(StandardCharsets.US_ASCII);
        System.arraycopy(magic, 0, h, 257, magic.length);
        h[262] = 0; h[263] = '0'; h[264] = '0';
        long checksum = 0;
        for (byte b : h) checksum += b & 0xff;
        tarOctal(h, 148, 8, checksum);
        out.write(h);
    }

    private static void tarOctal(byte[] buffer, int off, int len, long number) {
        String oct = Long.toOctalString(number);
        int start = off + len - 1 - oct.length();
        for (int i = off; i < off + len - 1; i++) buffer[i] = '0';
        for (int i = 0; i < oct.length() && start + i < off + len - 1; i++)
            buffer[start + i] = (byte) oct.charAt(i);
        buffer[off + len - 1] = 0;
    }

    private static void tarToZip(File input, File output) throws IOException {
        long total = 0; int count = 0;
        try (InputStream in = new BufferedInputStream(new FileInputStream(input));
             ZipOutputStream zip = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(output)))) {
            byte[] header = new byte[512];
            while (true) {
                if (!readFully(in, header, 512)) break;
                if (header[0] == 0) break;
                String name = nullTerminated(header, 0, 100);
                String prefix = nullTerminated(header, 345, 155);
                if (!prefix.isEmpty()) name = prefix + "/" + name;
                name = safeEntryName(name);
                long size = parseOctal(header, 124, 12);
                if (size < 0 || size > 150L * 1024 * 1024 || total + size > 200L * 1024 * 1024)
                    throw new IOException("Archivio TAR troppo grande.");
                total += size;
                if (++count > 1500) throw new IOException("Massimo 1.500 file per archivio.");
                byte type = header[156];
                if (!name.isEmpty() && (type == 0 || type == '0' || type == '5')) {
                    if (type == '5' && !name.endsWith("/")) name += "/";
                    zip.putNextEntry(new ZipEntry(name));
                    if (type != '5') copyExact(in, zip, size);
                    else skipFully(in, size);
                    zip.closeEntry();
                } else skipFully(in, size);
                skipFully(in, (512 - size % 512) % 512);
            }
        }
    }

    private static String nullTerminated(byte[] data, int off, int len) {
        int end = off;
        while (end < off + len && data[end] != 0) end++;
        return new String(data, off, end - off, StandardCharsets.UTF_8).trim();
    }

    private static long parseOctal(byte[] data, int off, int len) throws IOException {
        String s = nullTerminated(data, off, len).trim();
        if (s.isEmpty()) return 0;
        try { return Long.parseLong(s, 8); }
        catch (NumberFormatException ex) { throw new IOException("Intestazione TAR non valida."); }
    }

    private static void copyExact(InputStream in, OutputStream out, long length) throws IOException {
        byte[] buf = new byte[32 * 1024];
        while (length > 0) {
            int n = in.read(buf, 0, (int) Math.min(buf.length, length));
            if (n < 0) throw new IOException("Archivio troncato.");
            out.write(buf, 0, n);
            length -= n;
        }
    }

    private static boolean readFully(InputStream in, byte[] buffer, int length) throws IOException {
        int off = 0;
        while (off < length) {
            int n = in.read(buffer, off, length - off);
            if (n < 0) return off == 0 ? false : failedShortRead();
            off += n;
        }
        return true;
    }
    private static boolean failedShortRead() throws IOException { throw new IOException("Archivio TAR troncato."); }
    private static void skipFully(InputStream in, long size) throws IOException {
        while (size > 0) {
            long skipped = in.skip(size);
            if (skipped <= 0) {
                if (in.read() == -1) throw new IOException("Archivio TAR troncato.");
                skipped = 1;
            }
            size -= skipped;
        }
    }

    /** Remuxes an existing AAC audio track; it does not transcode arbitrary audio codecs. */
    private static void extractAacAudio(Context context, Uri uri, File output) throws Exception {
        MediaExtractor extractor = new MediaExtractor();
        MediaMuxer muxer = null;
        boolean started = false;
        try {
            extractor.setDataSource(context, uri, null);
            int audioIndex = -1;
            MediaFormat audioFormat = null;
            for (int i = 0; i < extractor.getTrackCount(); i++) {
                MediaFormat format = extractor.getTrackFormat(i);
                String mime = format.getString(MediaFormat.KEY_MIME);
                if (MediaFormat.MIMETYPE_AUDIO_AAC.equals(mime)) {
                    audioIndex = i; audioFormat = format; break;
                }
            }
            if (audioIndex < 0) throw new IOException("Il video non contiene una traccia AAC compatibile.");
            extractor.selectTrack(audioIndex);
            muxer = new MediaMuxer(output.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            int newTrack = muxer.addTrack(audioFormat);
            muxer.start(); started = true;
            ByteBuffer data = ByteBuffer.allocateDirect(1024 * 1024);
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            while (true) {
                data.clear();
                int size = extractor.readSampleData(data, 0);
                if (size < 0) break;
                info.offset = 0; info.size = size;
                info.presentationTimeUs = extractor.getSampleTime();
                info.flags = extractor.getSampleFlags();
                muxer.writeSampleData(newTrack, data, info);
                extractor.advance();
            }
        } finally {
            try { if (muxer != null) { if (started) muxer.stop(); muxer.release(); } }
            finally { extractor.release(); }
        }
    }
}
