package com.convertiora.android;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/** Discovery catalog: recognizing a filename is distinct from supporting a conversion. */
public final class FormatCatalog {
    private FormatCatalog() { }
    private static final String[][] TYPES = {
        {"Immagini", "jpg jpeg png webp gif bmp tiff tif svg ico heic heif avif psd psb raw dng cr2 cr3 nef arw raf orf rw2 pef srw tga eps exr hdr jxl jp2 j2k ppm pgm pbm pnm icns"},
        {"Documenti", "pdf doc docx docm dot dotx odt ott rtf txt html htm xhtml md markdown tex xps oxps pages wpd wps djvu djv log"},
        {"Fogli di calcolo", "xls xlsx xlsm xlsb xlt xltx ods ots csv tsv numbers dif sylk slk"},
        {"Presentazioni", "ppt pptx pptm pps ppsx pot potx odp otp key"},
        {"Audio", "mp3 wav aac m4a flac ogg oga opus wma aiff aif amr alac ac3 caf ape mid midi mka wv"},
        {"Video", "mp4 mkv mov avi webm wmv flv m4v 3gp 3g2 mpg mpeg ts mts m2ts ogv vob asf mxf"},
        {"Archivi", "zip rar 7z tar gz bz2 xz tgz tbz2 txz zst cab iso lzh lha arj cpio"},
        {"Ebook", "epub mobi azw azw3 fb2 cbz cbr lit prc pdb kepub"},
        {"Modelli 3D", "stl obj glb gltf fbx dae ply 3mf usdz blend step stp iges igs 3ds off"},
        {"Dati e sviluppo", "json jsonl xml yaml yml toml ini conf sql sqlite db bak csv tsv proto graphql"},
        {"Font", "ttf otf woff woff2 eot pfb pfa"}
    };
    private static final Set<String> ALL = new HashSet<>();
    static {
        for (String[] type : TYPES) ALL.addAll(Arrays.asList(type[1].split(" ")));
    }
    public static boolean recognized(String ext) { return ALL.contains(ext); }
    public static int count() { return ALL.size(); }
    public static String[][] categories() { return TYPES.clone(); }
}
