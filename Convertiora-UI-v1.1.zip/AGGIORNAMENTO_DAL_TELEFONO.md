# Convertiora 1.1 – Aggiornamento dell'app dal telefono Android

Questa versione cambia la schermata di conversione per renderla simile come funzionamento all'esempio fornito: **DA → A**, selettori a due riquadri, ricerca dei formati, elenco di categorie a sinistra e formati a destra. Il design rimane originale Convertiora.

## Cosa cambia

- I due selettori **DA** e **A** sono in alto, prima del caricamento dei file.
- Tocca **DA** per esplorare i formati riconosciuti. Dopo il caricamento di un file, il formato reale viene rilevato automaticamente e non può essere falsificato manualmente.
- Tocca **A** per scegliere il formato di uscita. I formati non supportati offline restano visibili nel catalogo, ma sono disattivati e non possono avviare conversioni false.
- Finestra con ricerca su tutto il catalogo, **11 categorie** e 190 estensioni riconosciute.
- Il motore locale è quello già esistente: non sono state aggiunte conversioni video, ebook o CAD che non sappiamo ancora eseguire.
- `versionCode` aumentato da 1 a 2; `versionName` ora `1.1.0`; stesso application ID debug: l'APK ottenuto può aggiornare la precedente installazione di prova.

## Aggiornare con il tuo GitHub dal solo telefono

Il tuo repository di prova è `https://github.com/Convertiora/Convertiora` e usa un workflow denominato **Convertiora APK** che estrae lo ZIP del progetto. Non c'è bisogno di creare un repository nuovo.

1. Scarica da questa chat **Convertiora-UI-v1.1.zip** sul telefono.
2. Nel tuo repository GitHub, premi **Add file → Upload files** e carica `Convertiora-UI-v1.1.zip`; premi **Commit changes**.
3. Apri `.github/workflows/convertiora-apk.yml` e seleziona **Edit file → In place**.
4. Trova la riga che estrae la vecchia versione: `unzip -qo Convertiora-Android-Sorgenti.zip`.
5. Sostituiscila con **esattamente**: `unzip -qo Convertiora-UI-v1.1.zip`.
6. Salva con **Commit changes**. GitHub avvierà un nuovo build automaticamente.
7. Vai su **Actions**, apri l'ultima esecuzione verde, scarica **Convertiora-APK** negli **Artifacts** e apri `app-debug.apk` dopo aver estratto l'archivio. Android potrà installare l'aggiornamento sopra la vecchia app, se è stato usato lo stesso certificato di firma debug. Se la firma cambia, potrebbe essere necessario disinstallare prima la build di prova.

**Attenzione**: questo ZIP è il progetto sorgente, non un APK. Il codice non è stato compilato né collaudato in questo ambiente, quindi un build GitHub potrebbe evidenziare errori da correggere.

## Perché non tutti i formati sono convertibili?

Il catalogo contiene **190 estensioni**. Queste indicano i file che l'app sa riconoscere e mostrare nella ricerca, non 190 conversioni complete. La conversione offline disponibile dipende dal tipo di file selezionato e dai motori Android implementati. Non è corretto dichiarare 190 conversioni funzionanti quando non ci sono.
