# Convertiora - Android / Google Play - release candidate 1.2

Progetto Android **nativo in Java** per conversioni locali. Preparato per una release Google Play, **non ancora compilato o collaudato su dispositivo in questo ambiente**. Questa cartella contiene **il codice sorgente, non un APK/AAB**. L’icona dell’app comparirà sul telefono soltanto dopo la compilazione e l’installazione di un APK vero.

## Novità della versione 1.2

- **01 · Scegli i file** ora compare **sopra** la sezione di conversione.
- **02 · Converti i file** mantiene i grandi selettori **DA → A**, ricerca e categorie della versione precedente.
- **03 · I tuoi file convertiti** continua a mostrare i risultati da salvare/condividere.
- **Selezione multipla reale, fino a 15 file** con `ACTION_OPEN_DOCUMENT` e `Intent.EXTRA_ALLOW_MULTIPLE`.
- Si possono **aggiungere altri file in selezioni successive** (prima le nuove scelte cancellavano l'elenco).
- Nuovo elenco numerato con nome, formato e dimensione di ciascun file; pulsante **✕** per rimuovere un singolo file e **Svuota lista** per rimuoverli tutti.
- Duplicati ignorati, limite dei 15 file indicato, dimensione totale visualizzata quando nota.
- Se si aggiungono file con formati differenti, il riquadro **DA** mostra **MISTI** e il programma offre soltanto conversioni di uscita compatibili con **tutti** i file. Se non ne esistono, spiega come risolvere.
- `versionCode` **3** / `versionName` **1.2.0**, package di prova invariato per consentire l'aggiornamento della versione 1.1.
- Le conversioni offline già implementate non sono state cambiate.

**Nota:** selezionare più file insieme non significa che ogni formato di input sia convertibile verso ogni formato di output. La conversione multipla usa la **stessa destinazione** per i file selezionati, e tutti i file devono supportarla.

Per aggiornare l'APK con il repository GitHub già configurato, leggi `AGGIORNAMENTO_DAL_TELEFONO.md`.

## Stato della consegna

**Fatto**
- `compileSdk 36`, `targetSdk 36` (requisito Google Play dal 31 agosto 2026 per le nuove app Android smartphone); `minSdk 26`.
- Gradle Android Plugin 8.13.2 + Gradle 8.13 + Java 17, workflow CI per test/lint/debug APK.
- Workflow separato che può generare un **AAB di release firmato** quando hai caricato la tua keystore e le relative password nei GitHub Secrets.
- Icona launcher Android (compresa adaptive icon), icona Google Play 512×512, feature graphic 1024×500.
- Schermata privacy dentro l'app, bozza HTML per sito web, copy Play Store in italiano, test unitari delle conversioni dichiarate, istruzioni test.
- SAF Android per scegliere/salvare documenti, nessun permesso `INTERNET`, nessun SDK di tracking/pubblicità.
- Esportazione file fuori dal thread principale, pulizia manuale dei risultati temporanei, stato selezione/risultati recuperato dopo una rotazione standard.

**Da completare prima di una pubblicazione reale**
- Compilazione con Android SDK e test manuale reale (non disponibili in questo ambiente). La pipeline GitHub Actions è predisposta ma non è stata eseguita.
- Inserire un identificativo pacchetto (`applicationId`) definitivo, dopo verifica di disponibilità, **prima del primo invio**. Quello corrente è `com.convertiora.android`. Cambiarlo anche nei package Java e nel namespace se si desidera una rifattorizzazione completa; non cambiare dopo la pubblicazione.
- Nome scelto: **Convertiora**. Prima della pubblicazione verificare disponibilità e possibili conflitti di marchio su Google Play e altri registri.
- Pubblicare `docs/privacy/index.html` su un URL HTTPS pubblico, modificando **[NOME_DELL_EDITORE]** e **[EMAIL_DI_CONTATTO]** con i dati reali; configurare la variabile `CONVERTIORA_PRIVACY_URL` nell'ambiente di build per rendere cliccabile il collegamento online nell'app.
- Scattare **almeno 2 screenshot veri** dell'app da dispositivo/emulatore: le immagini promozionali incluse NON sono screenshot e non sostituiscono questo requisito.
- Eseguire collaudo su più versioni Android, correggere bug emersi e verificare lint.
- Creare/collegare account Google Play Console, completare app content/Data safety/privacy policy/ratings, configurare **Play App Signing** e caricare AAB firmato.
- Se account sviluppatore personale creato dopo il 13/11/2023: prima dell'accesso alla produzione sono richiesti 12 tester con adesione continua a un test chiuso per almeno 14 giorni, e successiva domanda di accesso alla produzione (controllare requisiti attuali in Play Console).

## Conversioni attualmente implementate

| Input | Output | Condizioni |
| --- | --- | --- |
| JPG/JPEG, PNG, WEBP, GIF, BMP, HEIC/HEIF, AVIF | JPG, PNG, WEBP, PDF | Il decoder del dispositivo deve supportare l'immagine; GIF: solo primo fotogramma; immagini grandi ridimensionate |
| PDF | JPG o PNG | Tutte le pagine; più pagine = ZIP di immagini; max 80 pagine |
| TXT, MD, LOG, HTML, HTM, JSON, XML | TXT, PDF, HTML | Contenuto trattato come testo; HTML di input estratto come testo |
| DOCX / ODT | TXT, HTML, PDF | Estrazione testo, **non** preserva il layout Office |
| XLSX | TXT, PDF, CSV, TSV | Solo `sheet1.xml`; max 10.000 righe; date/formule/stili non fedeli |
| CSV / TSV | Testo, PDF, HTML e CSV↔TSV | Conversione campi delimitati con gestione delle virgolette |
| ZIP | TAR o TXT elenco | Limiti anti archivio eccessivo (max 1.500 voci) |
| TAR | ZIP | Limiti di sicurezza (max 1.500 voci) |
| MP4, MOV, M4V, 3GP | M4A | **Solo** audio AAC già presente; non è una transcodifica universale |

Molti altri formati sono **riconosciuti** dal catalogo, ma non convertibili: per formati quali RAR, PSD, MP3, OBJ, EPUB non viene inventato un pulsante non funzionante. Il limite sorgente è 250 MB per file e la selezione multipla arriva a 15 file (anche con aggiunte successive e rimozione individuale). I file temporanei non vanno considerati archiviazione permanente: usare **Salva**.

## Opzione A: genera un APK di prova via GitHub Actions (anche senza PC Android)

1. Crea un repository GitHub privato. Caricaci **il contenuto** di questa cartella, inclusa `.github/workflows/` (se carichi il solo ZIP devi estrarlo prima).
2. Nel repository, apri **Actions → Convertiora - Test, Lint, APK → Run workflow**. Viene installato automaticamente Android SDK 36.
3. Se test, lint e compilazione passano, scarica l'artefatto `Convertiora-debug-APK` e installa `app-debug.apk` sul telefono.
4. Esegui tutte le prove di `TEST_ANDROID.md`. **Non caricare l'APK debug come release Play Store.**

## Opzione B: genera AAB firmato per Google Play via GitHub Actions

1. Genera **tu** una upload key JKS su un PC sicuro, per esempio:
   `keytool -genkeypair -v -keystore convertiora-upload.jks -storetype JKS -alias convertiora-upload -keyalg RSA -keysize 3072 -validity 10000`
2. Conserva offline il file JKS e le due password: **se li perdi, l'aggiornamento dell'app può diventare problematico**. Non condividere mai questi dati in chat o nel codice.
3. Codifica il file JKS in Base64 (Linux: `base64 -w 0 convertiora-upload.jks`; macOS: `base64 < convertiora-upload.jks | tr -d '\n'`).
4. Nel repo vai su **Settings → Secrets and variables → Actions → New repository secret**. Crea i 4 segreti:
   - `CONVERTIORA_KEYSTORE_BASE64`: contenuto Base64 del JKS.
   - `CONVERTIORA_STORE_PASSWORD`: password della keystore.
   - `CONVERTIORA_KEY_ALIAS`: alias della chiave (es. `convertiora-upload`).
   - `CONVERTIORA_KEY_PASSWORD`: password della chiave.
5. Se hai già pubblicato la policy, crea una repository **variable** `CONVERTIORA_PRIVACY_URL` contenente il suo vero URL HTTPS; il workflow è già predisposto per leggerla. La build renderà cliccabile il collegamento online nell'app. (Senza variabile, la schermata mostra solo il testo locale e non è pronta per la revisione Play.)
6. Apri **Actions → Convertiora - Signed Play Store AAB → Run workflow**. Se la compilazione passa, scarica `Convertiora-signed-PlayStore-AAB` con `app-release.aab`.
7. Nel Play Console abilita **Play App Signing**; Google firma la distribuzione, mentre il bundle è firmato con la tua upload key. Carica il bundle nel canale di test, non subito in produzione. **Non inviare password o JKS a nessuno.**

Nota per il passaggio 5: nelle build locali puoi passare `-PCONVERTIORA_PRIVACY_URL=https://tuosito.it/privacy/` oppure impostare la variabile d'ambiente `CONVERTIORA_PRIVACY_URL`. La pipeline GitHub legge automaticamente `vars.CONVERTIORA_PRIVACY_URL`. Non usare URL finti.

## Opzione C: Android Studio

1. Apri la cartella progetto con Android Studio che supporti AGP 8.13; usa JDK 17 e Gradle 8.13.
2. Installa SDK platform Android 36 e Build Tools 35.0.0. Questo progetto **non include un file `gradlew`/wrapper ufficiale**, quindi serve una installazione Gradle 8.13 (oppure generare il wrapper con `gradle wrapper --gradle-version 8.13`).
3. Esegui `gradle :app:testDebugUnitTest :app:lintDebug :app:assembleDebug`.
4. Per `bundleRelease` imposta le variabili di firma e l'URL privacy come documentato sopra. Non impostare segreti in `build.gradle` o `gradle.properties` tracciati.

## Privacy e dichiarazioni Play Store

- La privacy policy è in `docs/privacy/index.html`. Puoi pubblicarla su un tuo sito HTTPS, oppure in un repository **pubblico** distinto usando GitHub Pages (per i repository privati la disponibilità di Pages dipende dal piano GitHub). Dopo aver sostituito i dati dell'editore, abilita **Settings → Pages → Deploy from a branch → main /docs**; il percorso tipico è `https://<utente>.github.io/<repo>/privacy/` (verifica l'URL effettivo nel browser).
- L'app non include un server, analytics o SDK pubblicitari. La dichiarazione *Data safety* deve rispecchiare **il codice finale effettivamente caricato**; non contrassegnare automaticamente caselle senza verifica.
- Categoria suggerita: **Strumenti**. Scheda in `playstore/scheda_play_store_IT.txt`.
- Icona: `playstore/assets/convertiora_icon_512.png`, grafica in evidenza `playstore/assets/convertiora_feature_1024x500.png`.
- Screenshot reali: assenti finché non viene eseguito il build su un dispositivo o emulatore.

## Note di qualità / limiti

- Convertiora è una **release candidate**, non una certificazione o garanzia di approvazione Google Play.
- Il motore per i documenti Office è volutamente semplificato; per fedeltà elevata servono altri componenti/licenze.
- I file generati sono nella cache privata e possono essere eliminati automaticamente; l'utente deve esportarli.
- Dimensioni molto grandi, input corrotti, PDF protetti e codec video non AAC possono produrre un messaggio d'errore.
- Non serve il permesso Android di accesso globale a foto/file: viene usato `ACTION_OPEN_DOCUMENT` e `ACTION_CREATE_DOCUMENT`.
- Il progetto non include librerie native; se se ne aggiungono, verificare i requisiti Android/Play relativi alle pagine di memoria e alle ABI.

## Riferimenti ufficiali

- [Requisiti target API Google Play](https://support.google.com/googleplay/android-developer/answer/11926878)
- [Materiali grafici](https://support.google.com/googleplay/android-developer/answer/9866151)
- [Privacy policy e revisione](https://support.google.com/googleplay/android-developer/answer/9859455)
- [Test per nuovi account personali](https://support.google.com/googleplay/android-developer/answer/14151465)
