# Convertiora 1.2 — Aggiornamento dal solo telefono Android

Questo archivio ZIP è **il codice sorgente**, non un APK direttamente installabile. Il tuo repository GitHub è già configurato e ha compilato correttamente la 1.1.

## Cosa cambia sullo schermo

1. **01 — Scegli i file dal telefono**: ora è la prima sezione. Seleziona fino a 15 file contemporaneamente o aggiungi altri file in più passaggi. Vedi elenco, nomi, estensioni e dimensioni; puoi eliminarli uno per uno con **✕** o tutti con **SVUOTA LISTA**.
2. **02 — Converti i file**: due riquadri **DA → A**, come la 1.1. L'app indica **MISTI** se hai caricato tipi diversi e abilita soltanto i formati di uscita comuni a tutti.
3. **03 — I tuoi file convertiti**: conserva i pulsanti Salva e Condividi.

## Passaggi precisi (Chrome/Samsung, senza PC)

1. Scarica in ChatGPT il file `Convertiora-UI-v1.2.zip`. **Non estrarlo**.
2. Apri `https://github.com/Convertiora/Convertiora/upload/main` e carica **Convertiora-UI-v1.2.zip**. Premi **Commit changes**.
3. Apri `https://github.com/Convertiora/Convertiora/blob/main/.github/workflows/convertiora-apk.yml`, menu **… → Edit file → In place**.
4. Cerca la riga `unzip -qo Convertiora-UI-v1.1.zip` e **sostituisci soltanto quella** con:

   `unzip -qo Convertiora-UI-v1.2.zip`

5. Premi **Commit changes**. Non toccare le altre righe di `sdkmanager` o Gradle: erano già state corrette.
6. Vai su `https://github.com/Convertiora/Convertiora/actions`, apri l'esecuzione verde più recente della voce **Convertiora APK**.
7. In **Artifacts** scarica `Convertiora-APK`. Lo ZIP scaricato da GitHub contiene `app-debug.apk`.
8. Apri **Archivio → Download**, estrai l'archivio GitHub appena scaricato e premi `app-debug.apk` → **Aggiorna**.
9. Apri Convertiora: deve mostrare **01 Scegli i file** prima di **02 Converti i file** e **Versione 1.2** in fondo.

### Attenzione alle versioni

- La vecchia esecuzione verde `#5` generava la versione precedente. Per questa modifica devi scaricare l'artefatto **dell'esecuzione più recente**, dopo i nuovi commit.
- Se GitHub segnala `cannot find or open Convertiora-UI-v1.2.zip`, controlla che lo ZIP sia presente nella pagina principale del repository, con quel nome esatto.
- Se GitHub segnala un errore nel passaggio **Build Android APK**, apri il passaggio rosso e condividi il testo dell'errore; questa versione non è stata compilata in questo ambiente.
- Se Android non installa l'aggiornamento per conflitto di firma, potrebbe essere necessario disinstallare la precedente **build di prova** (attenzione ai file convertiti non ancora salvati).
- Non pubblicare questo APK di debug su Google Play: per lo Store serve un AAB di release firmato, più gli altri requisiti di pubblicazione.
