# Collaudo Convertiora 1.2 - obbligatorio prima del Play Store

Stato: **non eseguito**, nessun APK compilato in questa sessione.

## CI / qualità
- [ ] GitHub Actions: `testDebugUnitTest`, `lintDebug`, `assembleDebug` verdi.
- [ ] GitHub Actions release: test/lint/bundle verdi con firma JKS personale.
- [ ] AAB firmato accettato dall'Internal Testing di Google Play senza errori.
- [ ] Verificare su Android 8.0, Android 11, Android 14, Android 16 (fisico o emulatore).
- [ ] Provare almeno un telefono piccolo, uno grande e rotazione/orientamento.

## Nuovi test obbligatori della 1.2
- [ ] Verificare ordine della UI: **01 Scegli i file**, **02 Converti i file**, **03 I tuoi file convertiti**.
- [ ] Selezionare 5 immagini nello stesso picker (multi-selezione) e verificare che appaiano tutte in elenco.
- [ ] Aggiungerne altre 3 in una seconda apertura: il conteggio deve passare da 5 a 8 senza cancellare le precedenti.
- [ ] Aggiungere di nuovo uno stesso file: deve apparire avviso di duplicato e non aumentare il totale.
- [ ] Rimuovere una sola immagine con **✕** e verificare che il numero diminuisca, il formato di uscita si aggiorni e le altre restino.
- [ ] Premi **SVUOTA LISTA** e verifica elenco vuoto, formati resettati e pulsante Converti disabilitato.
- [ ] Tentare più di 15 file in una volta e in aggiunte successive: non devono apparire più di 15 file; deve comparire un avviso.
- [ ] Selezionare JPG + PNG: il campo DA deve mostrare **MISTI** e A deve offrire solo formati di uscita comuni.
- [ ] Selezionare JPG + ZIP: il pulsante non deve avviare conversioni impossibili e deve apparire il messaggio di incompatibilità.
- [ ] Controllare la selezione multipla dopo rotazione o riapertura del selettore Android.
- [ ] Convertire 3 PNG in JPG e controllare che ci siano 3 risultati corretti.

## Flusso principale
- [ ] Aprire app, scegliere file da Download e da cloud provider tramite selettore documenti.
- [ ] PNG→JPG→WEBP; PNG con trasparenza→JPG (sfondo bianco).
- [ ] JPG→PDF; visualizzazione PDF in un lettore indipendente.
- [ ] PDF 1 pagina→JPG; PDF 3 pagine→ZIP con 3 file PNG.
- [ ] PDF cifrato o danneggiato: errore gestito, niente crash.
- [ ] TXT lungo→PDF multipagina; testo Unicode italiano.
- [ ] DOCX→TXT/PDF: verificare testo (non il layout).
- [ ] ODT→TXT e XLSX primo foglio→CSV, non promesse su formule.
- [ ] CSV con virgolette, virgole, riga interna→TSV→CSV.
- [ ] ZIP→TAR→ZIP, compresi nomi cartelle, file vuoti, nomi accentati.
- [ ] ZIP troppo grande e TAR non valido: errore senza crash o blocco.
- [ ] MP4 con AAC→M4A e ascolto traccia; MP4 non AAC mostra errore.
- [ ] Selezionare 5 file compatibili ed esportare risultati.
- [ ] Selezionare RAR o MP3: deve spiegare che la conversione non è disponibile.

## Privacy, permessi, accessibilità
- [ ] Controllare dal manifest risultante: nessun permesso INTERNET/READ_MEDIA/READ_EXTERNAL_STORAGE.
- [ ] Aprire informativa privacy dentro l'app e collegamento HTTPS, quando configurato.
- [ ] Nessuna rete, analytics, pubblicità o login.
- [ ] Condividere un risultato verso un'altra app e verificare che si apra.
- [ ] Salvare in Download tramite selettore e riaprire il file; annullare un salvataggio.
- [ ] Eliminare i risultati temporanei e verificare che spariscano dall'app.
- [ ] Ruotare la schermata: mantenere selezione e risultati quando non è in corso conversione.
- [ ] Con lettore schermo TalkBack: pulsanti selezione, converti, salva, condividi, privacy.
- [ ] Verificare font di sistema al 150-200% e navigazione gestuale (nessun elemento coperto dalle barre).

## Google Play Console
- [ ] Verificare nome app e unicità dell'applicationId; scegliere il definitivo.
- [ ] Pubblicare informativa con dati reali editore e URL HTTPS valido; inserire lo stesso URL nel Play Console.
- [ ] Inserire email assistenza e dati sviluppatore reali; non pubblicare segnaposto.
- [ ] Compilare dichiarazioni app content, target audience, annunci, accessi, classificazione contenuti, Data safety.
- [ ] Icona 512×512 PNG 32-bit, feature graphic 1024×500 PNG, e ALMENO 2 screenshot REALI dell'app.
- [ ] Configurare Google Play App Signing e caricare AAB firmato prima su Internal Testing.
- [ ] Per nuovo account personale, eventuale test chiuso 12 tester/14 giorni e richiesta accesso produzione.
- [ ] Attendere revisione ufficiale e correggere eventuali segnalazioni.
